package com.bank.banktransaction.controller;






import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.banktransaction.model.User;

import com.bank.banktransaction.service.BankService;

@RestController
@RequestMapping("/bankapi")
public class BankController {
	
	 private static final Logger logger = LogManager.getLogger(BankController.class);
	


	
    @Autowired
    private BankService service;
		
		// Register a User
		@PostMapping("/user")
		public User createUser(@RequestBody User user) {
			service.saveuser(user);
			logger.debug("Created A user",user);

			return user;
		}

}
